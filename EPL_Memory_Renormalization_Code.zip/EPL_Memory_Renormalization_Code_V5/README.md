# Reproducibility code — Measurement-dependent memory scaling in self-similar networks

This package contains the Python scripts and numerical CSV outputs used for the EPL manuscript (V5).

## Contents

- `code/generate_results.py` — Sierpinski-gasket constructions and baseline scaling calculations.
- `code/measure_renormalization.py` — projected low-frequency spectral-measure calculations and collapse diagnostics.
- `code/intermediate_sigma_test.py` — independent intermediate-support test at sigma = 1/2 on the Sierpinski gasket.
- `data/` — numerical outputs used in the manuscript and Supplement.
- `requirements.txt` — Python dependencies.

## Installation

Python 3 with NumPy, SciPy and Matplotlib is required.

```bash
python -m pip install -r requirements.txt
```

## Running

Run scripts from the package root. The intermediate-support script imports functions from `generate_results.py`; the scripts are supplied together in `code/`.

Typical commands:

```bash
cd code
python generate_results.py
python measure_renormalization.py
python intermediate_sigma_test.py
```

The calculations include the local and macroscopic observables, projected spectral-measure diagnostics, diamond-hierarchy scaling, and the sigma = 1/2 Sierpinski-gasket falsification test.

For archival publication, create a versioned GitHub release and archive that release with Zenodo so that the manuscript can cite a permanent DOI.
