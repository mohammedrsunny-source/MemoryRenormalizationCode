#!/usr/bin/env python3
"""Reproduce the numerical checks and figures for the EPL manuscript.

Only NumPy, SciPy and Matplotlib are required.
The graph is the standard unweighted finite Sierpinski-gasket graph.
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import null_space, eigh

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "figures"
DATA = ROOT / "data"
FIG.mkdir(exist_ok=True)
DATA.mkdir(exist_ok=True)


def sg_graph(n):
    """Return vertices, edges and combinatorial Laplacian of SG generation n."""
    verts = {(0, 0), (1, 0), (0, 1)}
    edges = {
        tuple(sorted(((0, 0), (1, 0)))),
        tuple(sorted(((0, 0), (0, 1)))),
        tuple(sorted(((1, 0), (0, 1)))),
    }
    scale = 1
    for _ in range(1, n + 1):
        offsets = [(0, 0), (scale, 0), (0, scale)]
        newv, newe = set(), set()
        for ox, oy in offsets:
            mp = {v: (v[0] + ox, v[1] + oy) for v in verts}
            newv.update(mp.values())
            for a, b in edges:
                newe.add(tuple(sorted((mp[a], mp[b]))))
        verts, edges = newv, newe
        scale *= 2
    verts = sorted(verts)
    idx = {v: i for i, v in enumerate(verts)}
    L = np.zeros((len(verts), len(verts)))
    for a, b in edges:
        i, j = idx[a], idx[b]
        L[i, i] += 1.0
        L[j, j] += 1.0
        L[i, j] -= 1.0
        L[j, i] -= 1.0
    return verts, sorted(edges), L


def xy(v):
    x, y = v
    return x + 0.5 * y, np.sqrt(3.0) * 0.5 * y


def subgasket_indices(verts, k):
    """Bottom-left generation-k subgasket."""
    s = 2 ** k
    return np.array([i for i, (x, y) in enumerate(verts) if x + y <= s], dtype=int)


def hidden_spectrum(L, p, tol=1e-12):
    """Exact scalar orthogonal Mori-Zwanzig hidden spectrum.

    P = p p^T, ||p||=1.  Q-basis is built with scipy.linalg.null_space.
    Returns active hidden eigenvalues, residues and full-space eigenvectors.
    """
    p = np.asarray(p, float)
    p /= np.linalg.norm(p)
    Z = null_space(p.reshape(1, -1))
    C = Z.T @ L @ Z
    vals, vecs = eigh(C)
    b = Z.T @ L @ p
    weights = (vecs.T @ b) ** 2
    keep = weights > tol
    return vals[keep], weights[keep], Z @ vecs[:, keep]


def slow_mode(L, p):
    vals, w, phi = hidden_spectrum(L, p)
    j = np.argmin(vals)
    return float(vals[j]), float(w[j]), phi[:, j]


def point_and_module_data(nmax=5):
    rows = []
    for n in range(1, nmax + 1):
        verts, _, L = sg_graph(n)
        N = len(verts)
        # Point observable at one outer corner.
        pp = np.zeros(N)
        pp[verts.index((0, 0))] = 1.0
        lp, wp, phip = slow_mode(L, pp)
        # Macroscopic average: one first-level subgasket, generation n-1.
        inds = subgasket_indices(verts, n - 1)
        pm = np.zeros(N)
        pm[inds] = 1.0 / np.sqrt(len(inds))
        lm, wm, phim = slow_mode(L, pm)
        # Exact identity check for non-zero-mean observables.
        rhs_p = lp**2 * (phip.sum() / pp.sum())**2
        rhs_m = lm**2 * (phim.sum() / pm.sum())**2
        rows.append({
            "n": n, "N": N, "M_module": len(inds),
            "lambda_point": lp, "weight_point": wp,
            "lambda_module": lm, "weight_module": wm,
            "identity_relerr_point": abs(wp-rhs_p)/wp,
            "identity_relerr_module": abs(wm-rhs_m)/wm,
        })
    return rows


def symmetry_data(nmax=5):
    rows = []
    for n in range(1, nmax + 1):
        verts, _, L = sg_graph(n)
        N = len(verts)
        left = verts.index((0, 0))
        right = verts.index((2**n, 0))
        for label, sign in [("even", 1.0), ("odd", -1.0)]:
            p = np.zeros(N)
            p[left] = 1 / np.sqrt(2)
            p[right] = sign / np.sqrt(2)
            lam, w, _ = slow_mode(L, p)
            rows.append({"n": n, "parity": label, "lambda": lam, "weight": w})
    return rows


def save_csv(rows, name):
    path = DATA / name
    with path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=rows[0].keys())
        writer.writeheader(); writer.writerows(rows)


def fig1_schematic():
    verts, edges, _ = sg_graph(3)
    inds = set(subgasket_indices(verts, 2).tolist())
    fig, ax = plt.subplots(figsize=(6.4, 4.6))
    for a, b in edges:
        xa, ya = xy(a); xb, yb = xy(b)
        ax.plot([xa, xb], [ya, yb], lw=0.8, alpha=0.65)
    pts = np.array([xy(v) for v in verts])
    ax.scatter(pts[:,0], pts[:,1], s=14, zorder=3)
    subpts = np.array([xy(verts[i]) for i in sorted(inds)])
    ax.scatter(subpts[:,0], subpts[:,1], s=35, facecolors='none', linewidths=1.2, zorder=4)
    x0, y0 = xy((0,0))
    ax.scatter([x0],[y0],s=95,marker='*',zorder=5)
    ax.text(x0+0.18,y0-0.18,"point observable",fontsize=9)
    ax.text(0.9,1.0,"macroscopic\nsubgasket average",fontsize=9)
    ax.set_aspect('equal'); ax.axis('off')
    fig.tight_layout()
    fig.savefig(FIG/"fig1_schematic.pdf", bbox_inches="tight")
    fig.savefig(FIG/"fig1_schematic.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig2_scaling(rows):
    n = np.array([r['n'] for r in rows])
    lp = np.array([r['lambda_point'] for r in rows])
    lm = np.array([r['lambda_module'] for r in rows])
    wp = np.array([r['weight_point'] for r in rows])
    wm = np.array([r['weight_module'] for r in rows])
    fig, ax = plt.subplots(figsize=(6.6,4.6))
    ax.plot(n[1:], lp[:-1]/lp[1:], 'o-', label=r'$\lambda_n/\lambda_{n+1}$, point')
    ax.plot(n[1:], lm[:-1]/lm[1:], 's-', label=r'$\lambda_n/\lambda_{n+1}$, average')
    ax.axhline(5.0, ls='--', lw=1, label=r'$5$')
    ax.set_xlabel('generation $n$')
    ax.set_ylabel('eigenvalue ratio')
    ax.legend(frameon=False, fontsize=8, loc='upper left')
    ax2 = ax.twinx()
    ax2.plot(n[1:], wp[1:]/wp[:-1], 'o:', label=r'$w_{n+1}/w_n$, point')
    ax2.plot(n[1:], wm[1:]/wm[:-1], 's:', label=r'$w_{n+1}/w_n$, average')
    ax2.axhline(3/25, ls='-.', lw=1)
    ax2.axhline(1/25, ls='-.', lw=1)
    ax2.set_ylabel('residue ratio')
    lines = ax2.get_lines()[:2]
    ax2.legend(lines, [l.get_label() for l in lines], frameon=False, fontsize=8, loc='center right')
    fig.tight_layout()
    fig.savefig(FIG/"fig2_scaling.pdf", bbox_inches="tight")
    fig.savefig(FIG/"fig2_scaling.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def fig3_symmetry(rows):
    even = [r for r in rows if r['parity']=='even']
    odd = [r for r in rows if r['parity']=='odd']
    n = np.array([r['n'] for r in even])
    le = np.array([r['lambda'] for r in even]); lo = np.array([r['lambda'] for r in odd])
    fig, ax = plt.subplots(figsize=(6.4,4.5))
    ax.semilogy(n, le, 'o-', label='symmetric observable')
    ax.semilogy(n, lo, 's-', label='antisymmetric observable')
    # guide with factor-five slope anchored at final even value
    guide = le[-1] * 5**(n[-1]-n)
    ax.semilogy(n, guide, '--', lw=1, label='factor-5 guide')
    ax.set_xlabel('generation $n$')
    ax.set_ylabel('slowest visible pole $\lambda_{\min}$')
    ax.legend(frameon=False, fontsize=8)
    ax.text(1.1, min(lo[0],1.0), 'different symmetry sectors', fontsize=9)
    fig.tight_layout()
    fig.savefig(FIG/"fig3_symmetry.pdf", bbox_inches="tight")
    fig.savefig(FIG/"fig3_symmetry.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


def main():
    pm = point_and_module_data(5)
    sy = symmetry_data(5)
    save_csv(pm, "point_module_scaling.csv")
    save_csv(sy, "symmetry_selection.csv")
    fig1_schematic(); fig2_scaling(pm); fig3_symmetry(sy)
    print("Generated figures in", FIG)
    print("Generated data in", DATA)
    print("Max relative error in residue identity:",
          max(max(r['identity_relerr_point'], r['identity_relerr_module']) for r in pm))

if __name__ == "__main__":
    main()
