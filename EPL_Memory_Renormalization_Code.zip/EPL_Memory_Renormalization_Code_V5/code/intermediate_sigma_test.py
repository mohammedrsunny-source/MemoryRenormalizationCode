#!/usr/bin/env python3
"""Intermediate-support (sigma=1/2) falsification test on the Sierpinski gasket."""
from pathlib import Path
import csv, numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import eigsh, LinearOperator
ROOT=Path(__file__).resolve().parents[1]; DATA=ROOT/'data'

def sg_sparse(n):
    verts={(0,0),(1,0),(0,1)}
    edges={tuple(sorted(((0,0),(1,0)))),tuple(sorted(((0,0),(0,1)))),tuple(sorted(((1,0),(0,1))))}
    scale=1
    for _ in range(1,n+1):
        nv=set(); ne=set()
        for ox,oy in [(0,0),(scale,0),(0,scale)]:
            mp={v:(v[0]+ox,v[1]+oy) for v in verts}; nv.update(mp.values())
            for a,b in edges: ne.add(tuple(sorted((mp[a],mp[b]))))
        verts,edges=nv,ne; scale*=2
    verts=sorted(verts); idx={v:i for i,v in enumerate(verts)}; N=len(verts)
    deg=np.zeros(N); rows=[]; cols=[]; dat=[]
    for a,b in edges:
        i,j=idx[a],idx[b]; deg[i]+=1;deg[j]+=1; rows += [i,j]; cols += [j,i]; dat += [-1.,-1.]
    rows += list(range(N)); cols += list(range(N)); dat += deg.tolist()
    return verts,coo_matrix((dat,(rows,cols)),shape=(N,N)).tocsr()

def slow_hidden(L,p,k=5,tau=80.):
    p=np.asarray(p,float); p/=np.linalg.norm(p); Lp=L@p
    def mv(x):
        q=x-p*np.dot(p,x); y=L@q; y=y-p*np.dot(p,y); return y+tau*p*np.dot(p,x)
    H=LinearOperator(L.shape,matvec=mv,dtype=float)
    vals,vecs=eigsh(H,k=min(k,L.shape[0]-2),which='SM',tol=3e-10,maxiter=100000)
    ix=np.argsort(vals); vals=vals[ix];vecs=vecs[:,ix]; b=Lp-p*np.dot(p,Lp);w=(vecs.T@b)**2
    for j in range(len(vals)):
        if vals[j]>1e-11 and w[j]>1e-20:
            return float(vals[j]),float(w[j]),float(vecs[:,j].sum()**2)
    raise RuntimeError('no active low mode')

rows=[]; prev=None
for n in [2,4,6,8]:
    verts,L=sg_sparse(n); k=n//2; side=2**k
    inds=[i for i,(x,y) in enumerate(verts) if x+y<=side]
    p=np.zeros(L.shape[0]); p[inds]=1/np.sqrt(len(inds))
    lam,w,S2=slow_hidden(L,p)
    row=dict(n=n,N=L.shape[0],k_support=k,M_support=len(inds),lambda0=lam,weight0=w,overlap_sq=S2,
             lambda_ratio_2gen='',weight_ratio_2gen='',overlap_ratio_2gen='',
             theory_lambda_ratio_2gen=25,theory_weight_ratio_2gen=3/625,theory_overlap_ratio_2gen=9)
    if prev:
        row['lambda_ratio_2gen']=prev['lambda0']/lam
        row['weight_ratio_2gen']=w/prev['weight0']
        row['overlap_ratio_2gen']=S2/prev['overlap_sq']
    rows.append(row); prev=row
with (DATA/'intermediate_sigma_sg.csv').open('w',newline='') as f:
    wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
for r in rows: print(r)
