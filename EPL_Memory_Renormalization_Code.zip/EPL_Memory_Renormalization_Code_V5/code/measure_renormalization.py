#!/usr/bin/env python3
"""Measure-level renormalization tests for the EPL manuscript."""
from pathlib import Path
import sys, csv
import numpy as np
import matplotlib.pyplot as plt
from scipy.sparse import csr_matrix, coo_matrix
from scipy.sparse.linalg import eigsh, LinearOperator

ROOT=Path(__file__).resolve().parents[1]
FIG=ROOT/'figures'; DATA=ROOT/'data'; FIG.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'code'))
from generate_results import sg_graph, subgasket_indices

def low_hidden_sg(n,kind,k=180):
    verts,_,Ld=sg_graph(n); L=csr_matrix(Ld); N=L.shape[0]
    p=np.zeros(N)
    if kind=='point': p[verts.index((0,0))]=1.0
    elif kind=='average':
        inds=subgasket_indices(verts,n-1); p[inds]=1/np.sqrt(len(inds))
    else: raise ValueError(kind)
    p/=np.linalg.norm(p); Lp=L@p; tau=20.
    def mv(x):
        q=x-p*np.dot(p,x); y=L@q; y=y-p*np.dot(p,y)
        return y+tau*p*np.dot(p,x)
    H=LinearOperator((N,N),matvec=mv,dtype=float)
    kk=min(k,N-2)
    vals,vecs=eigsh(H,k=kk,which='SM',tol=2e-11,maxiter=30000)
    ix=np.argsort(vals); vals=vals[ix]; vecs=vecs[:,ix]
    b=Lp-p*np.dot(p,Lp); w=(vecs.T@b)**2
    keep=(vals>1e-10)&(w>1e-18)
    vals,w,vecs=vals[keep],w[keep],vecs[:,keep]
    return vals,w,vecs,p

def diamond_graph(n, return_top=False):
    edges=[(0,1,None)]; N=2
    for level in range(n):
        ne=[]
        for a,b,label in edges:
            u,v=N,N+1; N+=2
            if level==0:
                ne += [(a,u,0),(u,b,0),(a,v,1),(v,b,1)]
            else:
                ne += [(a,u,label),(u,b,label),(a,v,label),(v,b,label)]
        edges=ne
    deg=np.zeros(N); rows=[]; cols=[]; dat=[]
    top=set()
    for a,b,label in edges:
        deg[a]+=1;deg[b]+=1;rows += [a,b];cols += [b,a];dat += [-1.,-1.]
        if label==0: top.update([a,b])
    rows += list(range(N)); cols += list(range(N)); dat += deg.tolist()
    L=coo_matrix((dat,(rows,cols)),shape=(N,N)).tocsr()
    return (L,sorted(top)) if return_top else L

def low_hidden_general(L,p,k=180):
    N=L.shape[0]; p=np.asarray(p,float); p/=np.linalg.norm(p); Lp=L@p; tau=50.
    def mv(x):
        q=x-p*np.dot(p,x); y=L@q; y=y-p*np.dot(p,y)
        return y+tau*p*np.dot(p,x)
    H=LinearOperator((N,N),matvec=mv,dtype=float)
    kk=min(k,N-2)
    vals,vecs=eigsh(H,k=kk,which='SM',tol=2e-11,maxiter=40000)
    ix=np.argsort(vals); vals=vals[ix]; vecs=vecs[:,ix]
    b=Lp-p*np.dot(p,Lp); w=(vecs.T@b)**2
    keep=(vals>1e-10)&(w>1e-18)
    return vals[keep],w[keep]

def low_hidden_diamond(n,kind='endpoint',k=180):
    L,top=diamond_graph(n,return_top=True); N=L.shape[0]
    if kind=='endpoint':
        p=np.zeros(N); p[0]=1.0
    elif kind=='average':
        p=np.zeros(N); p[top]=1/np.sqrt(len(top))
    else: raise ValueError(kind)
    return low_hidden_general(L,p,k), len(top)

def cumulative(v,w,x):
    o=np.argsort(v);v=v[o];w=w[o];cs=np.cumsum(w)
    ind=np.searchsorted(v,x,side='right')-1
    out=np.zeros_like(np.asarray(x),dtype=float);m=ind>=0;out[m]=cs[ind[m]]
    return out

def save_rows(rows,name):
    with (DATA/name).open('w',newline='') as f:
        wr=csv.DictWriter(f,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)

def main():
    sg={}; overlap=[]
    for kind in ['point','average']:
        sg[kind]={}
        prev=None
        for n in range(2,7):
            v,w,phi,p=low_hidden_sg(n,kind,180 if n>=5 else 100)
            sg[kind][n]=(v,w)
            S2=(phi[:,0].sum())**2
            overlap.append({'kind':kind,'n':n,'lambda0':v[0],'weight0':w[0],
                            'overlap_sq':S2,'overlap_ratio':np.nan if prev is None else S2/prev})
            prev=S2
    save_rows(overlap,'overlap_scaling.csv')

    # Pairwise cumulative-measure ratios at logarithmic test points.
    rows=[]
    for kind,a in [('point',3/25),('average',1/25)]:
        for n in range(3,6):
            v,w=sg[kind][n]; v2,w2=sg[kind][n+1]
            lo=max(v[0]*1.05,5*v2[0]*1.05); hi=min(1.0,v[-1],5*v2[-1])
            xs=np.geomspace(lo,hi,80); c1=cumulative(v,w,xs);c2=cumulative(v2,w2,xs/5)
            r=np.divide(c2,c1,out=np.full_like(c1,np.nan),where=c1>0)
            for x,rr in zip(xs,r):
                if np.isfinite(rr) and rr>0: rows.append({'kind':kind,'n_to_n1':f'{n}->{n+1}','lambda_scaled':x,'measure_ratio':rr,'theory':a})
    save_rows(rows,'spectral_measure_ratios.csv')

    # Fig: renormalized cumulative measures. ξ=b^n λ and a^{-n} cumulative weight.
    fig,axs=plt.subplots(1,2,figsize=(7.2,3.0))
    for ax,(kind,a,title) in zip(axs,[('point',3/25,'point observable'),('average',1/25,'macroscopic average')]):
        xis=np.geomspace(0.3,300,350)
        for n in range(3,7):
            v,w=sg[kind][n]
            y=cumulative(v,w,xis/(5**n))/(a**n)
            ax.step(xis,y,where='post',lw=1.1,label=f'n={n}')
        ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel(r'$\xi=5^n\lambda$');ax.set_title(title,fontsize=9)
        ax.grid(alpha=.18);ax.legend(frameon=False,fontsize=7)
    axs[0].set_ylabel(r'$a^{-n}\,\mu_n([0,\xi 5^{-n}])$')
    fig.tight_layout();fig.savefig(FIG/'fig_measure_collapse.pdf',bbox_inches='tight');fig.savefig(FIG/'fig_measure_collapse.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # Quantitative convergence metrics for the SG ratio curves.
    erows=[]
    for kind,a in [('point',3/25),('average',1/25)]:
        for n in range(3,6):
            v,w=sg[kind][n]; v2,w2=sg[kind][n+1]
            lo=max(v[0]*1.05,5*v2[0]*1.05); hi=min(1.0,v[-1],5*v2[-1])
            xs=np.geomspace(lo,hi,80); c1=cumulative(v,w,xs); c2=cumulative(v2,w2,xs/5)
            r=np.divide(c2,c1,out=np.full_like(c1,np.nan),where=c1>0)
            r=r[np.isfinite(r)&(r>0)]
            # Drop 10% at each edge to avoid endpoint/truncation artifacts in a staircase measure.
            q=max(1,int(round(.1*len(r)))); core=r[q:-q] if len(r)>2*q else r
            rel=core/a-1
            erows.append({'kind':kind,'n_to_n1':f'{n}->{n+1}','theory':a,
                          'median_ratio':float(np.median(r)),
                          'rms_relative_error_core80':float(np.sqrt(np.mean(rel**2))),
                          'max_relative_error_core80':float(np.max(np.abs(rel)))})
    save_rows(erows,'measure_convergence_metrics.csv')

    # Diamond hierarchy: two observables on the same architecture.
    dia={'endpoint':{},'average':{}}; drows=[]
    for kind in ['endpoint','average']:
        for n in range(2,7):
            (v,w),support=low_hidden_diamond(n,kind,180 if n>=5 else 100); dia[kind][n]=(v,w)
            drows.append({'kind':kind,'n':n,'N':diamond_graph(n).shape[0],'support':1 if kind=='endpoint' else support,'lambda0':v[0],'weight0':w[0]})
    save_rows(drows,'diamond_scaling.csv')
    fig,axs=plt.subplots(1,2,figsize=(7.0,3.0)); xis=np.geomspace(.3,200,320)
    for ax,(kind,a,title) in zip(axs,[('endpoint',1/4,'endpoint'),('average',1/16,'macroscopic average')]):
        for n in range(3,7):
            v,w=dia[kind][n]; y=cumulative(v,w,xis/(4**n))/(a**n); ax.step(xis,y,where='post',lw=1.1,label=f'n={n}')
        ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel(r'$\xi=4^n\lambda$');ax.set_title(title,fontsize=9);ax.legend(frameon=False,fontsize=7);ax.grid(alpha=.18)
    axs[0].set_ylabel(r'$a^{-n}\mu_n([0,\xi4^{-n}])$')
    fig.tight_layout();fig.savefig(FIG/'fig_diamond_collapse.pdf',bbox_inches='tight');fig.savefig(FIG/'fig_diamond_collapse.png',dpi=300,bbox_inches='tight');plt.close(fig)

    # concise console report
    print('SG overlap ratios (point):',[r['overlap_ratio'] for r in overlap if r['kind']=='point' and np.isfinite(r['overlap_ratio'])])
    print('SG overlap ratios (average):',[r['overlap_ratio'] for r in overlap if r['kind']=='average' and np.isfinite(r['overlap_ratio'])])
    for kind in ['endpoint','average']:
        print('Diamond',kind,'slow pole ratios:',[dia[kind][n][0][0]/dia[kind][n+1][0][0] for n in range(2,6)])
        print('Diamond',kind,'slow residue ratios:',[dia[kind][n+1][1][0]/dia[kind][n][1][0] for n in range(2,6)])

if __name__=='__main__': main()
